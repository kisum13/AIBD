# Intent Router 智能体意图路由

收到达人消息后，先完成以下识别：

## 1. Language
- English
- Spanish
- Korean
- Japanese
- Portuguese
- Other

## 2. Intent Category
- Project Introduction
- Pricing / Fixed Fee
- Revenue Share
- Contract Terms
- Licensing / Image Rights
- Exclusivity / Non-compete
- Net Revenue / Transparency
- Payment Schedule
- Deliverables / Posting
- Content Workflow
- Sample Projects / Cases
- Follow-up
- WhatsApp / Call
- Signing / Next Step

## 3. Creator Stage
- Cold reply
- Interested
- Negotiating
- Reviewing contract
- Ready to sign
- Signed
- Content development

## 4. Emotion
- Curious
- Interested
- Concerned
- Price-sensitive
- High intent
- Legal cautious
- Confused

## 5. Output Rule
根据 Intent 调用：
- Pricing → knowledge/pricing_fixed_fee.md + knowledge/revenue_share.md
- Contract → knowledge/contract_terms.md
- Content → knowledge/content_workflow.md
- Promotion → knowledge/promotion_distribution.md
- Cases → cases/platform_cases.md
- Follow-up → templates/follow_up.md

## 6. 回复结构
1. 感谢 / 认可
2. 回答核心问题
3. 补充项目逻辑
4. 推进下一步
5. 语气保持友好、商务、不过度催促
