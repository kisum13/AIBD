# Pricing Workflow

## 场景：达人嫌固定费低 / 想议价
回复策略：
1. 理解对方报价。
2. 说明固定费是内部标准化评估，主要看近期播放、互动、账号影响力。
3. 如果不能上调，明确 fixed fee 已是最高预算。
4. 推荐 Revenue Share。
5. 强调大部分近期合作创作者选择 Revenue Share。
6. 提供合同草案作为下一步。

## 场景：固定费非常低但达人形象适配
回复策略：
1. 不说具体低价。
2. 说 fixed fee budget cannot reach several hundred dollars.
3. 夸其外形 / 镜头感 / 题材适配。
4. 推荐 Revenue Share。
