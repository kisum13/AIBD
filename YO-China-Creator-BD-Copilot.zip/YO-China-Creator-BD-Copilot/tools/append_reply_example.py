import json
from pathlib import Path
from datetime import date

DATASET = Path(__file__).resolve().parents[1] / "training_data" / "reply_dataset.jsonl"

def append_example(example: dict):
    example.setdefault("last_updated", str(date.today()))
    with DATASET.open("a", encoding="utf-8") as f:
        f.write(json.dumps(example, ensure_ascii=False) + "\n")

if __name__ == "__main__":
    append_example({
        "id": "example_001",
        "language": "English",
        "category": "Pricing",
        "scenario": "Creator asks for higher fixed fee",
        "creator_message": "Can you increase the fee?",
        "recommended_reply": "Thank you for your message...",
        "notes": "Redirect to Revenue Share.",
        "stage": "Negotiating",
        "emotion": "Interested",
        "result": "pending"
    })
    print("Example appended.")
