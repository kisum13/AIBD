# User Prompt Template

请根据以下达人消息生成回复：

## 达人消息
{{creator_message}}

## 已知背景
- 达人语言：{{language}}
- 合作阶段：{{stage}}
- 报价 / 预算：{{budget}}
- 想重点推进：{{goal}}
- 注意事项：{{notes}}

## 输出要求
1. 先给目标语言回复。
2. 再给中文翻译。
3. 回复要商务、自然、清晰。
4. 不要承诺未确定事项。
5. 如果适合，推荐 Revenue Share。
