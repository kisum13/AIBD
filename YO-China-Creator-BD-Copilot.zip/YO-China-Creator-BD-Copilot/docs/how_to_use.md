# 如何使用这个项目

## 最简单用法
把整个文件夹上传到 Custom GPT / Claude Project / Cursor。

然后使用 `prompts/system_prompt.md` 作为智能体系统提示词。

## 日常使用流程
1. 复制达人消息。
2. 告诉 AI 背景：预算、语言、阶段、你想推进什么。
3. AI 生成回复。
4. 你审核修改。
5. 把最终版本沉淀到 `training_data/reply_dataset.jsonl`。

## 每周维护
- 新增 20–50 条真实达人问题与最终回复。
- 更新模板。
- 更新合同口径。
- 更新成功案例。
