# 收益分成 Revenue Share

## 标准比例
创作者获得项目 Net Revenue 的 80%。

## 推荐逻辑
多数近期合作创作者选择 Revenue Share，因为相比一次性固定付费，长期收益潜力更高。

## 适合对象
- 粉丝基数大
- 粉丝粘性强
- 账号剧情感 / 表演感 / 人设明确
- 对自己粉丝付费能力有信心

## 收益解释
用户通过平台一次性付费解锁整部剧，平均客单价约 USD 3.3。
收益取决于故事内容、粉丝活跃度、推广效果、平台分发等因素，不保证具体收益。

## 推广逻辑
收益分成不是创作者单方推广。平台也会做全球发行和推广。
双方共同推广越好，收益越高。

## 推荐表达
- We genuinely believe the Revenue Share model has much greater long-term earning potential.
- Most of our current creator partners have chosen this model.
- We are fully aligned in making the project successful because both sides benefit from stronger performance.
