# YO China Creator BD Copilot

一个面向海外达人 AI 短剧项目的 BD 智能体知识库与回复系统。

目标：把达人邮件 / WhatsApp 消息转化为可复用、可检索、可持续迭代的 BD 回复能力。

## 项目结构

```text
YO-China-Creator-BD-Copilot/
├── knowledge/          # 固定业务知识：项目、合同、收益、流程
├── templates/          # 多语言标准回复模板
├── workflows/          # 智能体决策流程
├── prompts/            # Custom GPT / Agent 系统提示词
├── training_data/      # 可持续沉淀的语料数据
├── cases/              # 成功案例、平台案例、达人案例
├── tools/              # 后续自动化脚本
└── docs/               # 使用说明
```

## 使用方式

1. 把达人消息复制给 AI。
2. AI 先识别语言、意图、阶段、情绪、风险。
3. 按 `workflows/intent_router.md` 找到对应知识和模板。
4. 生成一版符合 BD 语气的回复。
5. 人工审核后发送。
6. 把本次消息与最终回复沉淀进 `training_data/reply_dataset.jsonl`。

## 当前版本

v0.1：基于过往聊天初步搭建，可用于 Custom GPT / Claude Project / Cursor / Dify / RAGFlow。
